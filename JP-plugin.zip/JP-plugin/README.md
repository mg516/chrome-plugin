##### manifest.json
- name: 插件的名称
- version: 版本
- description: 描述
###### browser_action:插件的浏览器按钮行为
- default_icon: 默认的按钮图标
- default_title: 按钮标题（鼠标悬停时显示）
- default_popup: 默认的弹出框popup.html